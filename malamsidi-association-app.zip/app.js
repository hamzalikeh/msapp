let users = JSON.parse(localStorage.getItem("users")) || [];
let currentUser = null;

function register() {
  const name = document.getElementById("reg-name").value;
  const email = document.getElementById("reg-email").value;
  const password = document.getElementById("reg-password").value;

  if (users.find(user => user.email === email)) {
    alert("Email already exists.");
    return;
  }

  const newUser = {
    name,
    email,
    password,
    isAdmin: false,
    duesPaid: false
  };

  users.push(newUser);
  localStorage.setItem("users", JSON.stringify(users));
  alert("Registration successful! You can now log in.");
}

function login() {
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  const user = users.find(u => u.email === email && u.password === password);
  if (!user) {
    alert("Invalid login.");
    return;
  }

  currentUser = user;
  document.getElementById("auth").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
  document.getElementById("user-name").innerText = user.name;

  if (user.isAdmin) {
    document.getElementById("admin-panel-button").classList.remove("hidden");
  }

  showSection('announcements');
}

function logout() {
  currentUser = null;
  document.getElementById("auth").classList.remove("hidden");
  document.getElementById("dashboard").classList.add("hidden");
}

let announcements = JSON.parse(localStorage.getItem("announcements")) || [];
let events = JSON.parse(localStorage.getItem("events")) || [];

function showSection(name) {
  const main = document.getElementById("main-section");

  switch (name) {
    case "announcements":
      renderAnnouncements(main);
      break;
    case "events":
      renderEvents(main);
      break;
    case "constitution":
      renderConstitution(main);
      break;
    case "dues":
      renderDues(main);
      break;
    case "members":
      renderMembers(main);
      break;
    case "admin":
      renderAdminPanel(main);
      break;
    case "chat":
      main.innerHTML = `<p>Chat coming soon...</p>`;
      break;
    case "voting":
      main.innerHTML = `<p>Voting feature coming in Phase 3...</p>`;
      break;
    default:
      main.innerHTML = `<p>Page not found</p>`;
  }
}

function renderAnnouncements(main) {
  main.innerHTML = `<h3>Announcements</h3><ul id="announcement-list"></ul>`;
  const list = document.getElementById("announcement-list");
  announcements.forEach(item => {
    const li = document.createElement("li");
    li.innerText = item;
    list.appendChild(li);
  });
}

function renderEvents(main) {
  main.innerHTML = `<h3>Upcoming Events</h3><ul id="event-list"></ul>`;
  const list = document.getElementById("event-list");
  events.forEach(item => {
    const li = document.createElement("li");
    li.innerText = item;
    list.appendChild(li);
  });
}

function renderConstitution(main) {
  main.innerHTML = `
    <h3>Association Constitution</h3>
    <p><strong>Article 1:</strong> The association is founded to promote unity, academic excellence, and service.</p>
    <p><strong>Article 2:</strong> Membership is open to all students from Malam Sidi.</p>
    <p><strong>Article 3:</strong> The executive body shall be elected democratically every year.</p>
    <p><strong>Article 4:</strong> Members shall pay dues as determined by the executive committee.</p>
    <p><strong>Article 5:</strong> Amendments may be proposed by any member and must be voted on by majority.</p>
  `;
}

function renderDues(main) {
  const status = currentUser.duesPaid ? "✅ Paid" : "❌ Not Paid";
  main.innerHTML = `<h3>Dues Status</h3><p><strong>Your status:</strong> ${status}</p>`;
}

function renderMembers(main) {
  main.innerHTML = `<h3>All Registered Members</h3><ul id="member-list"></ul>`;
  const list = document.getElementById("member-list");
  users.forEach(user => {
    const li = document.createElement("li");
    li.innerText = \`\${user.name} (\${user.email})\`;
    list.appendChild(li);
  });
}

function renderAdminPanel(main) {
  if (!currentUser.isAdmin) {
    main.innerHTML = `<p>Access denied.</p>`;
    return;
  }

  main.innerHTML = \`
    <h3>Admin Panel</h3>

    <h4>Post Announcement</h4>
    <input id="admin-announcement" placeholder="Announcement text">
    <button onclick="addAnnouncement()">Add Announcement</button>

    <h4>Add Event</h4>
    <input id="admin-event" placeholder="Event details">
    <button onclick="addEvent()">Add Event</button>

    <h4>Mark Dues as Paid</h4>
    <input id="admin-dues-email" placeholder="User email">
    <button onclick="markDuesPaid()">Mark as Paid</button>
  \`;
}

function addAnnouncement() {
  const text = document.getElementById("admin-announcement").value;
  if (text.trim()) {
    announcements.push(text);
    localStorage.setItem("announcements", JSON.stringify(announcements));
    alert("Announcement added!");
    showSection("announcements");
  }
}

function addEvent() {
  const text = document.getElementById("admin-event").value;
  if (text.trim()) {
    events.push(text);
    localStorage.setItem("events", JSON.stringify(events));
    alert("Event added!");
    showSection("events");
  }
}

function markDuesPaid() {
  const email = document.getElementById("admin-dues-email").value;
  const user = users.find(u => u.email === email);
  if (user) {
    user.duesPaid = true;
    localStorage.setItem("users", JSON.stringify(users));
    alert(\`\${user.name}'s dues marked as paid.\`);
    if (user.email === currentUser.email) {
      currentUser.duesPaid = true;
    }
    showSection("dues");
  } else {
    alert("User not found.");
  }
}
