# Malam Sidi Student Association Web App

This is a web application for the Malam Sidi Student Association.

## Features
- Manual user registration and login
- Admin-controlled announcements and event posting
- Constitution section (written directly into the page)
- Voting system (admin creates polls)
- Dues tracking and status
- Member directory
- Chat system (coming in next phase)

Built with HTML, CSS, and JavaScript. No backend required (uses localStorage).
